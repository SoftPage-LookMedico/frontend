<script>
import SelectUser from "./public/pages/select-user.component.vue";


export default {
    name: 'App',
    components: {SelectUser}
}
</script>

<template>
  <pv-toast></pv-toast>
<select-user></select-user>

</template>

<style>
*{
  background-color: white;
}

</style>
